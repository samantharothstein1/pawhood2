const DOGS = [
  { id: 'luna', name: 'Luna', breed: 'Husky', age: '2 yrs', owner: 'Jordan Lee (you)', distance: '0.0 mi', color: '#E05A3A', bio: 'Blue-eyed troublemaker who loves snow, fetch, and howling along to the ice cream truck.' },
  { id: 'biscuit', name: 'Biscuit', breed: 'Golden Retriever', age: '3 yrs', owner: 'Sarah M.', distance: '0.3 mi', color: '#D4830A', bio: 'Friendliest dog at Fresh Pond. Will greet every human and dog within a 30-foot radius.' },
  { id: 'max', name: 'Max', breed: 'Beagle', age: '4 yrs', owner: 'Tom R.', distance: '0.7 mi', color: '#1A7A5C', bio: 'Nose to the ground 24/7. Expert at finding dropped snacks within seconds.' },
  { id: 'coco', name: 'Coco', breed: 'Poodle', age: '1 yr', owner: 'Elena V.', distance: '0.4 mi', color: '#3A7BD5', bio: 'Still a puppy at heart — loves belly rubs, squeaky toys, and short naps between zoomies.' },
  { id: 'rocky', name: 'Rocky', breed: 'Bulldog', age: '5 yrs', owner: 'James D.', distance: '0.9 mi', color: '#6B4226', bio: 'Low energy, high charm. Prefers a slow walk and a good nap in the sun.' },
  { id: 'daisy', name: 'Daisy', breed: 'Corgi', age: '2 yrs', owner: 'Mia S.', distance: '0.6 mi', color: '#3B6B35', bio: 'Small but mighty. Loves chasing squirrels she will never actually catch.' },
  { id: 'bear', name: 'Bear', breed: 'Newfoundland', age: '6 yrs', owner: 'Alex P.', distance: '1.1 mi', color: '#9E8070', bio: 'Gentle giant, great with puppies. Not a fan of the rain, despite the name.' },
  { id: 'pepper', name: 'Pepper', breed: 'Dachshund', age: '3 yrs', owner: 'Nora K.', distance: '0.8 mi', color: '#D4830A', bio: "Big personality in a small body. Barks at the mail carrier like it's a personal vendetta." },
];

const CATS = {
  Park: { bg: '#EDF6EB', color: '#3B6B35', icon: 'park' },
  Playdate: { bg: '#FEF4E0', color: '#D4830A', icon: 'pets' },
  Sitting: { bg: '#FBEAE5', color: '#E05A3A', icon: 'favorite' },
  Question: { bg: '#E8F1FD', color: '#3A7BD5', icon: 'help' },
};

let POSTS = [
  { id: 'p1', dogId: 'biscuit', category: 'Park', time: '2m ago', baseLikes: 12, comments: [
      { author: 'Priya K.', text: 'Biscuit and Luna need a rematch soon!' },
      { author: 'Tom R.', text: 'Fresh Pond in the morning is unbeatable.' },
      { author: 'Mia S.', text: 'Same here, Daisy had a blast today too.' },
    ], text: 'Just had the best morning at Fresh Pond! Biscuit made three new friends. Had the whole field to ourselves.' },
  { id: 'p2', dogId: 'coco', category: 'Sitting', time: '25m ago', baseLikes: 18, comments: [
      { author: 'Jordan Lee', text: 'I can help Saturday if you still need someone!' },
      { author: 'Alex P.', text: 'Coco is always welcome at ours.' },
    ], text: "Heading out of town next weekend — looking for someone to watch Coco Fri through Sun. She's easy, just needs two walks a day and loves belly rubs." },
  { id: 'p3', dogId: 'max', category: 'Question', time: '1h ago', baseLikes: 7, comments: [
      { author: 'Sarah M.', text: 'Cambridge Emergency Vet on Mass Ave is great, open all night.' },
      { author: 'Nora K.', text: 'Second that, they took care of Pepper last year.' },
    ], text: "Does anyone have a good recommendation for an after-hours emergency vet near Cambridge? Max ate something he shouldn't have and I want to be prepared." },
  { id: 'p4', dogId: 'daisy', category: 'Playdate', time: '3h ago', baseLikes: 5, comments: [
      { author: 'James D.', text: "Rocky's more of a nap-in-the-shade type but happy to come watch!" },
    ], text: "Daisy is looking for a playmate this Saturday at Danehy Park around 10am — she's small but mighty and loves other corgis and confident pups." },
  { id: 'p5', dogId: 'rocky', category: 'Park', time: '5h ago', baseLikes: 9, comments: [
      { author: 'Elena V.', text: 'Adding this to our list, looks lovely!' },
    ], text: 'Rocky and I checked out Christian Herter Park for the first time today. Great river trail, highly recommend for a change of scenery.' },
];

const PARKS = [
  { id: 'fresh-pond', name: 'Fresh Pond Off-Leash Area', city: 'Cambridge', hours: '6am–9pm', amenities: ['Off-leash', 'Water fountain', 'Shade'], dogIds: ['biscuit', 'daisy', 'pepper'], top: '18%', left: '30%' },
  { id: 'danehy', name: 'Danehy Park Dog Run', city: 'Cambridge', hours: 'Open 24 hours', amenities: ['Fenced', 'Benches', 'Trash bins'], dogIds: ['max', 'coco'], top: '42%', left: '65%' },
  { id: 'peters', name: 'Peters Park', city: 'Boston', hours: '6am–10pm', amenities: ['Off-leash hours', 'Agility equipment'], dogIds: ['bear'], top: '65%', left: '25%' },
  { id: 'herter', name: 'Christian Herter Park', city: 'Boston', hours: 'Sunrise–sunset', amenities: ['River trail', 'Off-leash area'], dogIds: ['rocky'], top: '78%', left: '58%' },
];

let THREADS = [
  { id: 't1', name: 'Sarah M.', color: '#D4830A', unread: 2, messages: [
      { text: 'Hi! Saw your post about Fresh Pond, mind if we join next time?', fromMe: false },
      { text: 'Of course! We usually go around 8am on weekends.', fromMe: true },
      { text: "Perfect, we'll be there Saturday!", fromMe: false },
    ] },
  { id: 't2', name: 'Elena V.', color: '#3A7BD5', unread: 0, messages: [
      { text: 'Thanks so much for offering to help with Coco!', fromMe: false },
      { text: 'Happy to — send over her schedule whenever.', fromMe: true },
    ] },
  { id: 't3', name: 'Tom R.', color: '#1A7A5C', unread: 1, messages: [
      { text: 'Emergency vet update: Max is totally fine, just a scare!', fromMe: false },
      { text: 'Oh good, so relieved to hear that.', fromMe: true },
    ] },
  { id: 't4', name: 'Mia S.', color: '#3B6B35', unread: 0, messages: [
      { text: 'Daisy had so much fun today, thank you!', fromMe: false },
      { text: "Luna too, let's do it again soon.", fromMe: true },
    ] },
  { id: 't5', name: 'James D.', color: '#6B4226', unread: 0, messages: [
      { text: 'Herter Park was great, thanks for the tip.', fromMe: false },
    ] },
];

const initials = name => name.trim()[0].toUpperCase();
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const state = {
  tab: 'home',
  view: null, // {type, id}
  parksMode: 'list',
  filter: null,
  composerDraft: '',
  composerCategory: 'Park',
  likes: { p1: true },
  friends: { biscuit: true, coco: true },
  checkins: {},
  notif: { push: true, likes: true, requests: true, checkins: false, messages: true, digest: false },
  privacy: { location: true, lastActive: false },
  visibility: 'neighborhood',
  commentDraft: '',
  messageDraft: '',
  account: { name: 'Jordan Lee', email: 'jordan.lee@email.com', phone: '(617) 555-0142' },
};

function goTab(tab) { state.tab = tab; state.view = null; render(); }
function open(type, id) { state.view = { type, id }; render(); }
function back() { state.view = null; state.commentDraft = ''; state.messageDraft = ''; render(); }
function toggleLike(id) { state.likes[id] = !state.likes[id]; render(); }
function toggleFriend(id) { state.friends[id] = !state.friends[id]; render(); }
function toggleCheckin(id) { state.checkins[id] = !state.checkins[id]; render(); }
function toggleNotif(key) { state.notif[key] = !state.notif[key]; render(); }
function togglePrivacy(key) { state.privacy[key] = !state.privacy[key]; render(); }
function setVisibility(v) { state.visibility = v; render(); }
function toggleFilter(cat) { state.filter = state.filter === cat ? null : cat; render(); }
function setComposerCategory(cat) { state.composerCategory = cat; render(); }
function setParksMode(m) { state.parksMode = m; render(); }

function addPost() {
  const draft = state.composerDraft.trim();
  if (!draft) return;
  POSTS = [{ id: 'new-' + Date.now(), dogId: 'luna', category: state.composerCategory, time: 'Just now', baseLikes: 0, comments: [], text: draft }, ...POSTS];
  state.composerDraft = '';
  render();
}
function submitComment() {
  const v = state.view, text = state.commentDraft.trim();
  if (!v || v.type !== 'post' || !text) return;
  const post = POSTS.find(p => p.id === v.id);
  if (post) post.comments.push({ author: 'Jordan Lee', text });
  state.commentDraft = '';
  render();
}
function sendMessage() {
  const v = state.view, text = state.messageDraft.trim();
  if (!v || v.type !== 'thread' || !text) return;
  const t = THREADS.find(t => t.id === v.id);
  if (t) { t.unread = 0; t.messages.push({ text, fromMe: true }); }
  state.messageDraft = '';
  render();
}

function dogById(id) { return DOGS.find(d => d.id === id); }

function friendBtnHtml(dog, big) {
  const isFriend = !!state.friends[dog.id];
  const bg = isFriend ? '#EDF6EB' : '#1A7A5C', color = isFriend ? '#3B6B35' : '#fff';
  const label = isFriend ? 'Requested' : 'Friend request';
  return `<button class="friend-btn" style="background:${bg};color:${color};${big ? 'padding:11px 28px;font-size:13.5px;width:auto;margin-top:14px;' : ''}" data-action="toggleFriend" data-id="${dog.id}">${label}</button>`;
}

function toggleHtml(on, action, key) {
  return `<div class="toggle" style="background:${on ? '#1A7A5C' : '#D8D2C8'}" data-action="${action}" data-key="${key}"><div class="knob" style="transform:translateX(${on ? 18 : 0}px)"></div></div>`;
}

function renderHomeTab() {
  const filterChips = Object.keys(CATS).map(cat => {
    const active = state.filter === cat, c = CATS[cat];
    return `<button class="chip" style="border-color:${active ? c.color : 'rgba(30,18,8,0.1)'};background:${active ? c.color : '#FFFCF7'};color:${active ? '#fff' : c.color}" data-action="toggleFilter" data-cat="${cat}"><span class="msym">${c.icon}</span>${cat}</button>`;
  }).join('');

  const composerCats = Object.keys(CATS).map(cat => {
    const active = state.composerCategory === cat, c = CATS[cat];
    return `<button class="cat-btn" style="border-color:${active ? c.color : 'rgba(30,18,8,0.1)'};background:${active ? c.color : '#FDF8F0'};color:${active ? '#fff' : c.color}" data-action="setComposerCategory" data-cat="${cat}">${cat}</button>`;
  }).join('');

  const posts = POSTS.filter(p => !state.filter || p.category === state.filter).map(p => {
    const dog = dogById(p.dogId), cat = CATS[p.category], liked = !!state.likes[p.id];
    const likeCount = p.baseLikes + (liked ? 1 : 0);
    return `<div class="card post-card">
      <div class="post-head">
        <button class="avatar" style="width:42px;height:42px;font-size:15px;background:${dog.color}" data-action="open" data-type="dog" data-id="${dog.id}">${initials(dog.name)}</button>
        <div class="post-meta" data-action="open" data-type="post" data-id="${p.id}">
          <div class="name">${esc(dog.name)}</div>
          <div class="sub">${esc(dog.owner)} · ${p.time}</div>
        </div>
        <span class="msym" style="font-size:20px;color:#C0A898">more_horiz</span>
      </div>
      <div style="margin:10px 0 6px"><span class="tag" style="background:${cat.bg};color:${cat.color}">${p.category}</span></div>
      <div class="post-text" data-action="open" data-type="post" data-id="${p.id}">${esc(p.text)}</div>
      <div class="post-actions">
        <button class="action-btn" style="color:${liked ? '#E05A3A' : '#9E8070'}" data-action="toggleLike" data-id="${p.id}"><span class="msym${liked ? ' filled' : ''}">favorite</span>${likeCount}</button>
        <button class="action-btn" style="color:#9E8070" data-action="open" data-type="post" data-id="${p.id}"><span class="msym">chat_bubble</span>${p.comments.length}</button>
      </div>
    </div>`;
  }).join('');

  return `
    <div class="header">
      <div><div class="title">Cambridge</div><div class="subtitle">${DOGS.length} dogs nearby · Fresh Pond area</div></div>
      <div style="display:flex;gap:8px">
        <button class="icon-btn"><span class="msym">search</span></button>
        <button class="icon-btn"><span class="msym">notifications</span></button>
      </div>
    </div>
    <div class="chip-row">${filterChips}</div>
    <div class="card composer">
      <div class="composer-row">
        <div class="avatar" style="width:40px;height:40px;font-size:15px;background:#E05A3A">L</div>
        <input class="input" id="composerInput" placeholder="What's Luna up to?" value="${esc(state.composerDraft)}" />
      </div>
      <div class="composer-footer">
        <div class="composer-cats">${composerCats}</div>
        <button class="pill-btn" style="background:#1A7A5C;color:#fff" data-action="addPost">Post</button>
      </div>
    </div>
    <div class="feed">${posts}</div>
  `;
}

function renderParksTab() {
  if (state.parksMode === 'map') {
    const pins = PARKS.map(p => `<button class="pin" style="left:${p.left};top:${p.top}" data-action="open" data-type="park" data-id="${p.id}">
        <div class="flag">${esc(p.name.split(' ')[0])} · ${p.dogIds.length}</div><div class="point"></div>
      </button>`).join('');
    return `
      <div class="header"><div><div class="title">Parks</div><div class="subtitle">4 spots near Cambridge &amp; Boston</div></div></div>
      <div class="mode-switch">
        <button class="mode-btn${state.parksMode === 'list' ? ' active' : ''}" data-action="setParksMode" data-mode="list">List</button>
        <button class="mode-btn${state.parksMode === 'map' ? ' active' : ''}" data-action="setParksMode" data-mode="map">Map</button>
      </div>
      <div class="map-box"><div class="label">map view placeholder</div>${pins}</div>
    `;
  }
  const list = PARKS.map(p => `<div class="card park-card" data-action="open" data-type="park" data-id="${p.id}">
      <div class="placeholder-photo park-photo">park photo</div>
      <div class="park-row">
        <div><div class="park-name">${esc(p.name)}</div><div class="park-sub">${p.city} · ${p.hours}</div></div>
        <div class="park-count"><div class="num">${p.dogIds.length}</div><div class="lbl">dogs now</div></div>
      </div>
      <div class="amenities">${p.amenities.map(a => `<span class="amenity">${esc(a)}</span>`).join('')}</div>
    </div>`).join('');
  return `
    <div class="header"><div><div class="title">Parks</div><div class="subtitle">4 spots near Cambridge &amp; Boston</div></div></div>
    <div class="mode-switch">
      <button class="mode-btn${state.parksMode === 'list' ? ' active' : ''}" data-action="setParksMode" data-mode="list">List</button>
      <button class="mode-btn${state.parksMode === 'map' ? ' active' : ''}" data-action="setParksMode" data-mode="map">Map</button>
    </div>
    <div class="park-list">${list}</div>
  `;
}

function renderDogsTab() {
  const grid = DOGS.filter(d => d.id !== 'luna').map(d => `<div class="card dog-card">
      <button class="avatar" style="width:64px;height:64px;font-size:22px;background:${d.color}" data-action="open" data-type="dog" data-id="${d.id}">${initials(d.name)}</button>
      <div class="name">${esc(d.name)}</div>
      <div class="breed">${esc(d.breed)} · ${d.age}</div>
      <div class="dist">${d.distance}</div>
      ${friendBtnHtml(d)}
    </div>`).join('');
  return `
    <div class="header"><div><div class="title">Dogs</div><div class="subtitle">7 pups in your neighborhood</div></div></div>
    <div class="dog-grid">${grid}</div>
  `;
}

function renderMessagesTab() {
  const unreadCount = THREADS.reduce((n, t) => n + (t.unread > 0 ? 1 : 0), 0);
  const list = THREADS.map(t => {
    const preview = t.messages[t.messages.length - 1].text;
    return `<button class="thread-item" data-action="open" data-type="thread" data-id="${t.id}">
        <div class="avatar" style="width:48px;height:48px;font-size:17px;background:${t.color}">${initials(t.name)}</div>
        <div style="flex:1;min-width:0">
          <div class="top"><div class="name">${esc(t.name)}</div><div class="time">Recent</div></div>
          <div class="preview" style="font-weight:${t.unread > 0 ? 800 : 600}">${esc(preview)}</div>
        </div>
        ${t.unread > 0 ? '<div class="dot"></div>' : ''}
      </button>`;
  }).join('');
  return `
    <div class="header"><div><div class="title">Messages</div><div class="subtitle">${unreadCount > 0 ? unreadCount + ' unread conversations' : 'All caught up'}</div></div></div>
    <div class="thread-list">${list}</div>
  `;
}

function renderProfileTab() {
  const friendCount = Object.values(state.friends).filter(Boolean).length;
  const rows = [
    { label: 'Notifications', icon: 'notifications', bg: '#EDF6EB', color: '#3B6B35', id: 'notifications' },
    { label: 'Privacy', icon: 'lock', bg: '#E8F1FD', color: '#3A7BD5', id: 'privacy' },
    { label: 'Account', icon: 'person', bg: '#FEF4E0', color: '#D4830A', id: 'account' },
    { label: 'Help & support', icon: 'help', bg: '#F1EBE0', color: '#6B4226', id: null },
    { label: 'Log out', icon: 'logout', bg: '#FBEAE5', color: '#E05A3A', id: null, danger: true },
  ].map(r => `<button class="settings-row" ${r.id ? `data-action="open" data-type="settings" data-id="${r.id}"` : ''}>
      <div class="icon-box" style="background:${r.bg}"><span class="msym" style="color:${r.color}">${r.icon}</span></div>
      <div class="label" style="color:${r.danger ? '#E05A3A' : '#1E1208'}">${r.label}</div>
      <span class="msym chev">chevron_right</span>
    </button>`).join('');
  return `
    <div class="profile-head">
      <div class="avatar profile-avatar" style="background:#E05A3A">L</div>
      <div class="profile-name">Luna</div>
      <div class="profile-sub">Husky · 2 yrs · with Jordan Lee</div>
      <div class="stat-row">
        <div class="stat"><div class="num">${friendCount}</div><div class="lbl">Friends</div></div>
        <div class="stat"><div class="num">14</div><div class="lbl">Posts</div></div>
        <div class="stat"><div class="num">27</div><div class="lbl">Park visits</div></div>
      </div>
    </div>
    <div class="settings-list">${rows}</div>
  `;
}

function renderTabBar() {
  const unreadCount = THREADS.reduce((n, t) => n + (t.unread > 0 ? 1 : 0), 0);
  const tabs = [
    { key: 'home', icon: 'home', label: 'Home' },
    { key: 'parks', icon: 'park', label: 'Parks' },
    { key: 'dogs', icon: 'pets', label: 'Dogs' },
    { key: 'messages', icon: 'chat_bubble', label: 'Messages', badge: unreadCount },
    { key: 'profile', icon: 'person', label: 'Profile' },
  ];
  return `<div class="tab-bar">${tabs.map(t => {
    const active = state.tab === t.key, color = active ? '#1A7A5C' : '#B8A090';
    return `<button class="tab-btn" data-action="goTab" data-tab="${t.key}">
        <span class="msym${active ? ' filled' : ''}" style="color:${color}">${t.icon}</span>
        <span class="label" style="color:${color}">${t.label}</span>
        ${t.badge ? `<div class="tab-badge">${t.badge}</div>` : ''}
      </button>`;
  }).join('')}</div>`;
}

function renderPostView() {
  const p = POSTS.find(p => p.id === state.view.id);
  if (!p) return '';
  const dog = dogById(p.dogId), cat = CATS[p.category], liked = !!state.likes[p.id];
  const likeCount = p.baseLikes + (liked ? 1 : 0);
  const comments = p.comments.map(c => `<div style="display:flex;gap:10px">
      <div class="avatar" style="width:34px;height:34px;font-size:13px;background:#DDF5EE;color:#1A7A5C">${initials(c.author)}</div>
      <div class="card" style="padding:10px 12px;flex:1"><div style="font-weight:800;font-size:12.5px;color:#1E1208">${esc(c.author)}</div><div style="font-size:13px;color:#2C1A0E;margin-top:2px;line-height:1.4">${esc(c.text)}</div></div>
    </div>`).join('');
  return `<div class="scroll">
    <div class="detail-header"><button class="back-btn" data-action="back"><span class="msym">arrow_back</span></button><div class="detail-title">Post</div></div>
    <div style="padding:0 20px 16px">
      <div class="post-head">
        <button class="avatar" style="width:46px;height:46px;font-size:16px;background:${dog.color}" data-action="open" data-type="dog" data-id="${dog.id}">${initials(dog.name)}</button>
        <div><div class="name">${esc(dog.name)}</div><div class="sub">${esc(dog.owner)} · ${p.time}</div></div>
      </div>
      <div style="margin:12px 0 6px"><span class="tag" style="background:${cat.bg};color:${cat.color}">${p.category}</span></div>
      <div style="font-size:15px;color:#2C1A0E;line-height:1.5">${esc(p.text)}</div>
      <div class="placeholder-photo tan" style="height:160px;border-radius:16px;margin-top:12px">photo placeholder</div>
      <div style="display:flex;gap:20px;margin-top:14px;padding:12px 0;border-top:1px solid rgba(30,18,8,0.08);border-bottom:1px solid rgba(30,18,8,0.08)">
        <button class="action-btn" style="color:${liked ? '#E05A3A' : '#9E8070'};font-size:13.5px" data-action="toggleLike" data-id="${p.id}"><span class="msym${liked ? ' filled' : ''}" style="font-size:19px">favorite</span>${likeCount} likes</button>
        <div class="action-btn" style="color:#9E8070;font-size:13.5px"><span class="msym" style="font-size:19px">chat_bubble</span>${p.comments.length} comments</div>
      </div>
    </div>
    <div style="flex:1;display:flex;flex-direction:column;gap:14px;padding:0 20px 12px">${comments}</div>
    <div class="compose-bar">
      <input class="input round" id="commentInput" placeholder="Add a comment…" value="${esc(state.commentDraft)}" />
      <button class="send-btn" data-action="submitComment"><span class="msym">send</span></button>
    </div>
  </div>`;
}

function renderDogView() {
  const d = dogById(state.view.id);
  if (!d) return '';
  const photos = [1, 2, 3].map(() => `<div class="placeholder-photo" style="aspect-ratio:1;border-radius:12px;font-size:9.5px">photo</div>`).join('');
  return `<div class="scroll">
    <div class="detail-header"><button class="back-btn" data-action="back"><span class="msym">arrow_back</span></button></div>
    <div style="display:flex;flex-direction:column;align-items:center;text-align:center;padding:8px 20px 18px">
      <div class="avatar" style="width:92px;height:92px;font-size:32px;background:${d.color}">${initials(d.name)}</div>
      <div style="font-size:22px;font-weight:900;color:#1E1208;margin-top:10px">${esc(d.name)}</div>
      <div style="font-size:13px;color:#9E8070;font-weight:600;margin-top:2px">${esc(d.breed)} · ${d.age} · ${d.distance}</div>
      <div style="font-size:12.5px;color:#B8A090;font-weight:600;margin-top:2px">with ${esc(d.owner)}</div>
      ${friendBtnHtml(d, true)}
    </div>
    <div style="padding:0 20px 8px"><div class="section-label">About</div><div style="font-size:14px;color:#2C1A0E;line-height:1.5">${esc(d.bio)}</div></div>
    <div style="padding:16px 20px 28px"><div class="section-label">Photos</div><div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">${photos}</div></div>
  </div>`;
}

function renderParkView() {
  const park = PARKS.find(p => p.id === state.view.id);
  if (!park) return '';
  const extra = state.checkins[park.id] ? [dogById('luna')] : [];
  const checkedIn = [...park.dogIds.map(dogById), ...extra];
  const checkedInHtml = checkedIn.map(d => `<div class="card" style="display:flex;align-items:center;gap:10px;padding:10px 12px">
      <div class="avatar" style="width:36px;height:36px;font-size:13px;background:${d.color}">${initials(d.name)}</div>
      <div style="font-weight:700;font-size:13.5px;color:#1E1208">${esc(d.name)}</div>
    </div>`).join('');
  const checkedInNow = state.checkins[park.id];
  return `<div class="scroll">
    <div class="detail-header"><button class="back-btn" data-action="back"><span class="msym">arrow_back</span></button></div>
    <div class="placeholder-photo" style="margin:0 20px 16px;height:160px;border-radius:18px">park photo</div>
    <div style="padding:0 20px">
      <div style="font-size:21px;font-weight:900;color:#1E1208">${esc(park.name)}</div>
      <div style="font-size:13px;color:#9E8070;font-weight:600;margin-top:3px">${park.city} · ${park.hours}</div>
      <div class="amenities">${park.amenities.map(a => `<span class="amenity">${esc(a)}</span>`).join('')}</div>
      <button class="friend-btn" style="width:100%;padding:13px 0;font-size:14px;background:${checkedInNow ? '#EDF6EB' : '#1A7A5C'};color:${checkedInNow ? '#3B6B35' : '#fff'};margin-top:16px" data-action="toggleCheckin" data-id="${park.id}">${checkedInNow ? 'Checked in ✓' : 'Check in here'}</button>
    </div>
    <div style="padding:20px 20px 28px">
      <div class="section-label">${checkedIn.length} dogs checked in now</div>
      <div style="display:flex;flex-direction:column;gap:10px">${checkedInHtml}</div>
    </div>
  </div>`;
}

function renderThreadView() {
  const t = THREADS.find(t => t.id === state.view.id);
  if (!t) return '';
  const bubbles = t.messages.map(m => `<div class="bubble-row" style="justify-content:${m.fromMe ? 'flex-end' : 'flex-start'}">
      <div class="bubble" style="background:${m.fromMe ? '#1A7A5C' : '#FFFCF7'};color:${m.fromMe ? '#fff' : '#1E1208'}">${esc(m.text)}</div>
    </div>`).join('');
  return `<div style="flex:1;display:flex;flex-direction:column">
    <div class="detail-header" style="border-bottom:1px solid rgba(30,18,8,0.06)">
      <button class="back-btn" data-action="back"><span class="msym">arrow_back</span></button>
      <div class="avatar" style="width:34px;height:34px;font-size:13px;background:${t.color}">${initials(t.name)}</div>
      <div class="detail-title">${esc(t.name)}</div>
    </div>
    <div class="thread-body">${bubbles}</div>
    <div class="compose-bar">
      <input class="input round" id="messageInput" placeholder="Message…" value="${esc(state.messageDraft)}" />
      <button class="send-btn" data-action="sendMessage"><span class="msym">send</span></button>
    </div>
  </div>`;
}

function renderSettingsNotif() {
  const labels = { push: 'Push notifications', likes: 'Likes & comments', requests: 'New friend requests', checkins: 'Park check-ins nearby', messages: 'Direct messages', digest: 'Weekly digest email' };
  const rows = Object.keys(labels).map(key => `<div class="simple-row"><div class="label">${labels[key]}</div>${toggleHtml(state.notif[key], 'toggleNotif', key)}</div>`).join('');
  return `<div class="scroll">
    <div class="detail-header"><button class="back-btn" data-action="back"><span class="msym">arrow_back</span></button><div class="detail-title">Notifications</div></div>
    <div style="display:flex;flex-direction:column;padding:0 20px 24px;gap:4px">${rows}</div>
  </div>`;
}

function renderSettingsPrivacy() {
  const vis = [['everyone', 'Everyone'], ['neighborhood', 'Neighborhood'], ['friends', 'Friends only']]
    .map(([key, label]) => `<button class="seg-btn${state.visibility === key ? ' active' : ''}" data-action="setVisibility" data-vis="${key}">${label}</button>`).join('');
  return `<div class="scroll">
    <div class="detail-header"><button class="back-btn" data-action="back"><span class="msym">arrow_back</span></button><div class="detail-title">Privacy</div></div>
    <div style="padding:0 20px 8px">
      <div class="section-label">Who can see your profile</div>
      <div class="seg-switch">${vis}</div>
    </div>
    <div style="display:flex;flex-direction:column;padding:20px 20px 24px;gap:4px">
      <div class="simple-row"><div><div class="label">Show my location</div><div class="sub">Others can see your approximate location</div></div>${toggleHtml(state.privacy.location, 'togglePrivacy', 'location')}</div>
      <div class="simple-row"><div><div class="label">Show last active</div><div class="sub">Show when you were last on Pawhood</div></div>${toggleHtml(state.privacy.lastActive, 'togglePrivacy', 'lastActive')}</div>
      <button class="simple-row" style="margin-top:12px"><div class="label">Blocked users</div><div style="display:flex;align-items:center;gap:4px;color:#9E8070;font-size:13px;font-weight:600">0 <span class="msym" style="font-size:18px;color:#C0A898">chevron_right</span></div></button>
    </div>
  </div>`;
}

function renderSettingsAccount() {
  return `<div class="scroll">
    <div class="detail-header"><button class="back-btn" data-action="back"><span class="msym">arrow_back</span></button><div class="detail-title">Account</div></div>
    <div style="display:flex;flex-direction:column;padding:0 20px 20px">
      <div class="form-field"><div class="form-label">Your name</div><input class="field-input" id="accountName" value="${esc(state.account.name)}" /></div>
      <div class="form-field"><div class="form-label">Email</div><input class="field-input" id="accountEmail" value="${esc(state.account.email)}" /></div>
      <div class="form-field"><div class="form-label">Phone</div><input class="field-input" id="accountPhone" value="${esc(state.account.phone)}" /></div>
    </div>
    <div style="display:flex;flex-direction:column;padding:4px 20px 8px;gap:4px">
      <button class="simple-row"><div class="label">Change password</div><span class="msym" style="font-size:18px;color:#C0A898">chevron_right</span></button>
      <div class="simple-row"><div><div class="label">Luna</div><div class="sub">Linked dog profile</div></div><div class="avatar" style="width:34px;height:34px;font-size:13px;background:#E05A3A">L</div></div>
      <button style="display:flex;align-items:center;gap:8px;padding:13px 4px;border:none;background:none;cursor:pointer;text-align:left;color:#1A7A5C;font-weight:800;font-size:14px"><span class="msym">add_circle</span>Add another dog</button>
    </div>
    <div style="padding:12px 20px 28px"><button class="danger-btn">Delete account</button></div>
  </div>`;
}

function render() {
  const screen = document.getElementById('screen');
  let html = '<div class="status-spacer"></div>';
  const v = state.view;
  if (!v) {
    html += '<div class="scroll">';
    if (state.tab === 'home') html += renderHomeTab();
    else if (state.tab === 'parks') html += renderParksTab();
    else if (state.tab === 'dogs') html += renderDogsTab();
    else if (state.tab === 'messages') html += renderMessagesTab();
    else if (state.tab === 'profile') html += renderProfileTab();
    html += '</div>' + renderTabBar();
  } else if (v.type === 'post') html += renderPostView();
  else if (v.type === 'dog') html += renderDogView();
  else if (v.type === 'park') html += renderParkView();
  else if (v.type === 'thread') html += renderThreadView();
  else if (v.type === 'settings' && v.id === 'notifications') html += renderSettingsNotif();
  else if (v.type === 'settings' && v.id === 'privacy') html += renderSettingsPrivacy();
  else if (v.type === 'settings' && v.id === 'account') html += renderSettingsAccount();

  screen.innerHTML = html;
  wireInputs();
}

function wireInputs() {
  const bind = (id, cb) => { const el = document.getElementById(id); if (el) el.addEventListener('input', e => cb(e.target.value)); };
  bind('composerInput', v => { state.composerDraft = v; });
  bind('commentInput', v => { state.commentDraft = v; });
  bind('messageInput', v => { state.messageDraft = v; });
  bind('accountName', v => { state.account.name = v; });
  bind('accountEmail', v => { state.account.email = v; });
  bind('accountPhone', v => { state.account.phone = v; });
}

document.getElementById('screen').addEventListener('click', e => {
  const el = e.target.closest('[data-action]');
  if (!el) return;
  const a = el.dataset.action;
  if (a === 'open') open(el.dataset.type, el.dataset.id);
  else if (a === 'back') back();
  else if (a === 'goTab') goTab(el.dataset.tab);
  else if (a === 'toggleLike') toggleLike(el.dataset.id);
  else if (a === 'toggleFriend') toggleFriend(el.dataset.id);
  else if (a === 'toggleCheckin') toggleCheckin(el.dataset.id);
  else if (a === 'toggleFilter') toggleFilter(el.dataset.cat);
  else if (a === 'setComposerCategory') setComposerCategory(el.dataset.cat);
  else if (a === 'addPost') addPost();
  else if (a === 'setParksMode') setParksMode(el.dataset.mode);
  else if (a === 'submitComment') submitComment();
  else if (a === 'sendMessage') sendMessage();
  else if (a === 'toggleNotif') toggleNotif(el.dataset.key);
  else if (a === 'togglePrivacy') togglePrivacy(el.dataset.key);
  else if (a === 'setVisibility') setVisibility(el.dataset.vis);
});

render();
